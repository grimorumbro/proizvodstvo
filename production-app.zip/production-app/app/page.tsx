export default function HomePage() {
  return (
    <main style={{ padding: 24, fontFamily: "Arial, sans-serif" }}>
      <h1>Production App</h1>
      <p>Каркас приложения запущен.</p>
      <p>Админка: /admin</p>
      <p>Публичная страница заказа: /p/[token]</p>
    </main>
  );
}
