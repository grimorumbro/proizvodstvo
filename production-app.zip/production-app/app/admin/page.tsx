export default function AdminPage() {
  return (
    <main style={{ padding: 24, fontFamily: "Arial, sans-serif" }}>
      <h1>Админка Production App</h1>
      <p>Здесь позже будут настройки воронки, сотрудников и QR.</p>
    </main>
  );
}
