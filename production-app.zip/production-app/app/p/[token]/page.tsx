import { headers } from "next/headers";

type Props = { params: Promise<{ token: string }> };

async function getOrder(token: string) {
  const headerStore = await headers();
  const host = headerStore.get("host") || "localhost:3000";
  const proto = process.env.NODE_ENV === "production" ? "https" : "http";
  const res = await fetch(`${proto}://${host}/api/public/order/${token}`, { cache: "no-store" });
  return res.json();
}

export default async function PublicOrderPage({ params }: Props) {
  const { token } = await params;
  const result = await getOrder(token);

  if (!result.success) {
    return (
      <main style={{ padding: 24, fontFamily: "Arial, sans-serif" }}>
        <h1>Заказ не найден</h1>
        <p>{result.message ?? "Ошибка доступа"}</p>
      </main>
    );
  }

  const deal = result.data.deal as Record<string, unknown>;

  return (
    <main style={{ padding: 24, fontFamily: "Arial, sans-serif", maxWidth: 520 }}>
      <h1>Производственный заказ</h1>
      <p><strong>ID:</strong> {result.data.dealId}</p>
      <p><strong>Название:</strong> {String(deal.TITLE ?? "—")}</p>
      <p><strong>Стадия:</strong> {String(deal.STAGE_ID ?? "—")}</p>
      <form action={`/api/public/order/${token}/complete-stage`} method="post" style={{ display: "grid", gap: 12, marginTop: 20 }}>
        <textarea name="comment" placeholder="Комментарий к завершению этапа" rows={4} style={{ width: "100%", padding: 12 }} />
        <button type="submit" style={{ padding: 12 }}>Завершить этап</button>
      </form>
    </main>
  );
}
