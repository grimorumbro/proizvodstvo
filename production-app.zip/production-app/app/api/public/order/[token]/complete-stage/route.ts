import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getSessionEmployeeId } from "@/lib/auth";
import { getDealById, updateDeal } from "@/lib/vibe";
import { getNextStage } from "@/lib/stages";

const schema = z.object({ comment: z.string().max(1000).optional() });

type Params = { params: Promise<{ token: string }> };

export async function POST(req: NextRequest, { params }: Params) {
  const { token } = await params;
  const employeeId = await getSessionEmployeeId();
  if (!employeeId) {
    return NextResponse.json({ success: false, message: "Требуется авторизация по PIN" }, { status: 401 });
  }

  const contentType = req.headers.get("content-type") || "";
  const body = contentType.includes("application/json")
    ? await req.json()
    : Object.fromEntries((await req.formData()).entries());

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, message: "Некорректные данные" }, { status: 400 });
  }

  const qr = await db.qrToken.findFirst({ where: { token, active: true } });
  if (!qr) {
    return NextResponse.json({ success: false, message: "QR токен не найден" }, { status: 404 });
  }

  const config = await db.appConfig.findUnique({ where: { id: 1 } });
  if (!config) {
    return NextResponse.json({ success: false, message: "Конфигурация приложения не настроена" }, { status: 500 });
  }

  const vibeResponse = await getDealById(qr.dealId);
  const deal = vibeResponse.data;
  const currentStage = String((deal as Record<string, unknown>).STAGE_ID ?? "");
  if (!currentStage) {
    return NextResponse.json({ success: false, message: "Не удалось определить текущую стадию" }, { status: 500 });
  }

  const nextStage = await getNextStage(config.pipelineId, currentStage);
  if (!nextStage) {
    return NextResponse.json({ success: false, message: "Для стадии не настроен следующий переход" }, { status: 400 });
  }

  const updatePayload: Record<string, unknown> = { stageId: nextStage };
  if (config.commentFieldCode && parsed.data.comment) updatePayload[config.commentFieldCode] = parsed.data.comment;
  if (config.actorFieldCode) updatePayload[config.actorFieldCode] = String(employeeId);

  await updateDeal(qr.dealId, updatePayload);

  await db.operationLog.create({
    data: {
      dealId: qr.dealId,
      qrTokenId: qr.id,
      employeeId,
      previousStage: currentStage,
      nextStage,
      comment: parsed.data.comment,
    },
  });

  return NextResponse.json({
    success: true,
    data: { dealId: qr.dealId, previousStage: currentStage, nextStage },
  });
}
