import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getDealById } from "@/lib/vibe";

type Params = { params: Promise<{ token: string }> };

export async function GET(_req: NextRequest, { params }: Params) {
  const { token } = await params;
  const qr = await db.qrToken.findFirst({ where: { token, active: true } });

  if (!qr) {
    return NextResponse.json({ success: false, message: "QR токен не найден" }, { status: 404 });
  }

  const vibeResponse = await getDealById(qr.dealId);
  return NextResponse.json({
    success: true,
    data: {
      dealId: qr.dealId,
      token,
      deal: vibeResponse.data,
    },
  });
}
