import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";

const pinSchema = z.object({ pin: z.string().min(4).max(12) });

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = pinSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, message: "Некорректный PIN" }, { status: 400 });
  }

  const employees = await db.employee.findMany({ where: { active: true } });
  for (const employee of employees) {
    const ok = await bcrypt.compare(parsed.data.pin, employee.pinHash);
    if (ok) {
      await createSession(employee.id);
      return NextResponse.json({
        success: true,
        data: { employeeId: employee.id, employeeName: employee.name },
      });
    }
  }

  return NextResponse.json({ success: false, message: "PIN не найден" }, { status: 401 });
}
