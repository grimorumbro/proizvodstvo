import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";

const employeeSchema = z.object({
  name: z.string().min(1),
  pin: z.string().min(4).max(12),
});

export async function GET() {
  const employees = await db.employee.findMany({
    orderBy: { id: "desc" },
    select: { id: true, name: true, active: true, createdAt: true },
  });

  return NextResponse.json({ success: true, data: employees });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = employeeSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ success: false, error: parsed.error.flatten() }, { status: 400 });
  }

  const pinHash = await bcrypt.hash(parsed.data.pin, 10);
  const employee = await db.employee.create({
    data: { name: parsed.data.name, pinHash },
    select: { id: true, name: true, active: true, createdAt: true },
  });

  return NextResponse.json({ success: true, data: employee }, { status: 201 });
}
