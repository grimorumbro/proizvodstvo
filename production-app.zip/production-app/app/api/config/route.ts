import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const configSchema = z.object({
  pipelineId: z.number().int().positive(),
  qrFieldCode: z.string().optional().nullable(),
  tokenFieldCode: z.string().optional().nullable(),
  commentFieldCode: z.string().optional().nullable(),
  actorFieldCode: z.string().optional().nullable(),
  transitionEnabled: z.boolean().default(true),
});

export async function GET() {
  const config = await db.appConfig.findUnique({ where: { id: 1 } });
  return NextResponse.json({ success: true, data: config });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = configSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ success: false, error: parsed.error.flatten() }, { status: 400 });
  }

  const config = await db.appConfig.upsert({
    where: { id: 1 },
    update: parsed.data,
    create: { id: 1, ...parsed.data },
  });

  return NextResponse.json({ success: true, data: config });
}
