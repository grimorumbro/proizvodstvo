import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { buildPublicOrderUrl, buildQrDataUrl, generateToken } from "@/lib/qr";

const schema = z.object({ dealId: z.number().int().positive() });

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, message: "Некорректный dealId" }, { status: 400 });
  }

  const token = generateToken();
  const qrRow = await db.qrToken.create({
    data: { dealId: parsed.data.dealId, token },
  });

  const publicUrl = buildPublicOrderUrl(token);
  const qrDataUrl = await buildQrDataUrl(token);

  return NextResponse.json({
    success: true,
    data: { id: qrRow.id, token, publicUrl, qrDataUrl },
  });
}
