import { db } from "./db";

export async function getNextStage(pipelineId: number, currentStage: string): Promise<string | null> {
  const row = await db.stageMap.findFirst({
    where: {
      pipelineId,
      fromStage: currentStage,
      active: true,
    },
  });

  return row?.toStage ?? null;
}
