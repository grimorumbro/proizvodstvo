import crypto from "crypto";
import QRCode from "qrcode";
import { env } from "./env";

export function generateToken(): string {
  return crypto.randomBytes(24).toString("hex");
}

export function buildPublicOrderUrl(token: string): string {
  return `${env.APP_BASE_URL}/p/${token}`;
}

export async function buildQrDataUrl(token: string): Promise<string> {
  return QRCode.toDataURL(buildPublicOrderUrl(token));
}
