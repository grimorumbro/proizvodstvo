import { env } from "./env";

type VibeRequestOptions = {
  method?: "GET" | "POST" | "PATCH" | "DELETE";
  body?: unknown;
};

async function parseResponse(response: Response) {
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    return { raw: text };
  }
}

export async function vibeRequest<T>(path: string, options: VibeRequestOptions = {}): Promise<T> {
  const method = options.method ?? "GET";
  const response = await fetch(`${env.VIBE_BASE_URL}${path}`, {
    method,
    headers: {
      "X-Api-Key": env.VIBE_API_KEY,
      "Content-Type": "application/json",
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
    cache: "no-store",
  });

  const data = await parseResponse(response);

  if (!response.ok) {
    const message =
      data?.error?.message ||
      data?.message ||
      `Vibe request failed with status ${response.status}`;
    throw new Error(message);
  }

  return data as T;
}

export async function getDealById(dealId: number) {
  return vibeRequest<{ success: boolean; data: Record<string, unknown> }>(`/deals/${dealId}`);
}

export async function updateDeal(dealId: number, payload: Record<string, unknown>) {
  return vibeRequest<{ success: boolean; data: Record<string, unknown> }>(`/deals/${dealId}`, {
    method: "PATCH",
    body: payload,
  });
}
