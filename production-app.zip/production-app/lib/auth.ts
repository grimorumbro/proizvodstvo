import crypto from "crypto";
import { cookies } from "next/headers";
import { env } from "./env";

const COOKIE_NAME = "production_app_session";
const SESSION_TTL_SECONDS = 60 * 60 * 24;

type SessionPayload = {
  employeeId: number;
  exp: number;
};

function sign(value: string): string {
  return crypto.createHmac("sha256", env.SESSION_SECRET).update(value).digest("hex");
}

export async function createSession(employeeId: number) {
  const payload: SessionPayload = {
    employeeId,
    exp: Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS,
  };

  const raw = JSON.stringify(payload);
  const encoded = Buffer.from(raw).toString("base64url");
  const signature = sign(encoded);

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, `${encoded}.${signature}`, {
    httpOnly: true,
    sameSite: "lax",
    secure: true,
    path: "/",
    maxAge: SESSION_TTL_SECONDS,
  });
}

export async function getSessionEmployeeId(): Promise<number | null> {
  const cookieStore = await cookies();
  const cookieValue = cookieStore.get(COOKIE_NAME)?.value;
  if (!cookieValue) return null;

  const [encoded, signature] = cookieValue.split(".");
  if (!encoded || !signature) return null;
  if (sign(encoded) !== signature) return null;

  const json = Buffer.from(encoded, "base64url").toString("utf8");
  const payload = JSON.parse(json) as SessionPayload;
  if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
  return payload.employeeId ?? null;
}
