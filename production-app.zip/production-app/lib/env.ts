function getEnv(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required env variable: ${name}`);
  return value;
}

export const env = {
  VIBE_API_KEY: getEnv("VIBE_API_KEY"),
  VIBE_BASE_URL: getEnv("VIBE_BASE_URL"),
  APP_BASE_URL: getEnv("APP_BASE_URL"),
  SESSION_SECRET: getEnv("SESSION_SECRET"),
  BITRIX_ENTITY_TYPE: process.env.BITRIX_ENTITY_TYPE ?? "deal",
  DEFAULT_PIPELINE_ID: Number(process.env.DEFAULT_PIPELINE_ID ?? "1"),
};
